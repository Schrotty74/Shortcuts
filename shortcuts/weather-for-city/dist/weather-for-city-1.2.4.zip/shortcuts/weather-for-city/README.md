# Weather for City

Version: `1.2.4`

Deutsch: [README.de.md](README.de.md)

`Weather for City` is an Apple Shortcut for Mac and iPhone.

The shortcut asks for a city, resolves the matching location through
Open-Meteo, fetches current weather data, and shows it as a notification, a
result view, and an animated HTML weather card.

![Weather for City HTML preview](assets/html-preview.svg)

Download [the interactive weather preview](assets/weather-preview.html) and open it in a browser to try the weather effects. The iCloud link below installs version 1.2.3.

## Installation

1. Open the [official iCloud shortcut link](https://www.icloud.com/shortcuts/27ee79aa7dd0427babb6758cef78c06b).
2. Import it into Apple Shortcuts.
3. Run the shortcut and enter a city.

## Included Files

- `Weather_for_City.xml` - readable XML source
- `PRIVACY_REPORT.md` - privacy report
- `CHECKSUMS.txt` - SHA-256 checksums
- `assets/html-preview.svg` - compact preview image of the HTML weather card

## Features

- free city input
- remembers the last selected location locally so `Get Weather` can run without
  asking for the city or location choice again
- separate `Change City` menu item for replacing the saved location
- location picker for ambiguous city names such as `Columbia`
- current temperature in Celsius or Fahrenheit, selected from the found city's country code
- WMO weather code converted to a readable description
- animated weather card
- weather scene based on the weather code
- dynamic temperature color from `-15 °C` to `+50 °C`
- Fahrenheit display for US, Bahamas, Cayman Islands, Liberia, and Myanmar
- built-in update check against the latest GitHub release
- responsive layouts for Mac and iPhone
- German visible shortcut texts and HTML output for `de-AT`, `de-DE`, `de-CH`, `de-LI`
- English fallback for all other device languages and regions
- official iCloud installation link for iPhone and Mac
- privacy report, signed shortcut file, release ZIP, and SHA-256 checksums

## First Run And Permissions

On the first and sometimes also the second run, iOS/macOS may show Apple
Shortcuts permission prompts. The exact prompts depend on what you choose in
the start menu:

- `Get Weather` can ask to contact Open-Meteo, show a notification, open the
  HTML preview, and save/read the last selected location in the local Shortcuts
  file area.
- `Change City` can ask again because it replaces the locally saved location.
- `Check for Update` can ask to contact GitHub and open the latest release page.

These prompts come from Apple Shortcuts and cannot be fully disabled by the
shortcut. After the first confirmed weather run, `Get Weather` can reuse the
saved selected location without asking for the city or location choice again.
Use `Change City` when you want to replace it.

## Data Sources

The shortcut uses public Open-Meteo endpoints:

- `https://geocoding-api.open-meteo.com/v1/search`
- `https://api.open-meteo.com/v1/forecast`

No API key is required.
